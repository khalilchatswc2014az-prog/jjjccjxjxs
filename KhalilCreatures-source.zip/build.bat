@echo off
setlocal
cd /d "%~dp0"
echo === Khalil Creatures - automatic build ===

java -version 2>&1 | findstr /C:"1.8" >nul
if errorlevel 1 (
  echo [ERROR] Java 8 ^(JDK 8^) is required. Install JDK 8 and set JAVA_HOME, then run again.
  pause
  exit /b 1
)

set MDK_URL=https://maven.minecraftforge.net/net/minecraftforge/forge/1.7.10-10.13.4.1614-1.7.10/forge-1.7.10-10.13.4.1614-1.7.10-src.zip

if not exist mdk\gradlew.bat (
  echo Downloading Forge MDK 1.7.10...
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest '%MDK_URL%' -OutFile mdk.zip"
  if errorlevel 1 ( echo [ERROR] Download failed. & pause & exit /b 1 )
  powershell -NoProfile -Command "Expand-Archive -Force mdk.zip mdk"
)

echo Copying mod sources...
if exist mdk\src\main\java\com\example rmdir /s /q mdk\src\main\java\com\example
xcopy /E /Y /I src mdk\src >nul
copy /Y build.gradle mdk\build.gradle >nul

cd mdk
call gradlew.bat setupDecompWorkspace
if errorlevel 1 ( echo [ERROR] setupDecompWorkspace failed. Send me the error text. & pause & exit /b 1 )
call gradlew.bat build
if errorlevel 1 ( echo [ERROR] build failed. Send me the error text. & pause & exit /b 1 )

copy /Y build\libs\KhalilCreatures-1.7.10.jar ..\KhalilCreatures-1.7.10.jar
echo.
echo DONE: KhalilCreatures-1.7.10.jar is next to this file. Put it in your mods folder.
pause
