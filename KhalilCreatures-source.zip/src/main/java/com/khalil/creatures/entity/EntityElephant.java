package com.khalil.creatures.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import com.khalil.creatures.ModItems;

/** Herbivore: never hunts, but hits hard when attacked. */
public class EntityElephant extends EntityKhalilAnimal {

    public EntityElephant(World world) {
        super(world);
        this.setSize(2.0F, 2.9F);
        this.stepHeight = 1.0F;
    }

    @Override
    protected double getBaseHealth() {
        return 60.0D;
    }

    @Override
    protected double getBaseSpeed() {
        return 0.2D;
    }

    @Override
    protected double getBaseDamage() {
        return 10.0D;
    }

    @Override
    protected boolean isPredator() {
        return false;
    }

    @Override
    protected boolean isPrey(Entity entity) {
        return false;
    }

    @Override
    protected Item getTemptItem() {
        return Items.wheat;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        Item item = stack.getItem();
        return item == Items.wheat || item == Items.apple;
    }

    @Override
    protected Item getRawMeat() {
        return ModItems.rawElephantMeat;
    }

    @Override
    protected Item getCookedMeat() {
        return ModItems.cookedElephantMeat;
    }

    @Override
    public EntityAgeable createChild(EntityAgeable mate) {
        return new EntityElephant(this.worldObj);
    }

    @Override
    protected String getLivingSound() {
        return "khalilcreatures:elephant.call";
    }

    @Override
    protected String getHurtSound() {
        return "khalilcreatures:elephant.hurt";
    }

    @Override
    protected String getDeathSound() {
        return "khalilcreatures:elephant.death";
    }

    @Override
    protected String getStepSound() {
        return "khalilcreatures:elephant.step";
    }

    @Override
    protected float getSoundVolume() {
        return 1.4F;
    }

    @Override
    public int getTalkInterval() {
        return 300;
    }
}
