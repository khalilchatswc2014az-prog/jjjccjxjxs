package com.khalil.creatures.entity;

import net.minecraft.block.Block;
import net.minecraft.command.IEntitySelector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIFollowParent;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIMate;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAITempt;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;

/**
 * Shared behaviour of Lion / Tiger / Elephant.
 *
 * AI: swim, melee attack, mate, follow parent, tempt with food, wander, look.
 * They are neutral: they only attack when hurt (and call nearby relatives for help).
 * Predators (lion, tiger) also hunt sheep, cows, pigs and chickens.
 */
public abstract class EntityKhalilAnimal extends EntityAnimal {

    private final IEntitySelector preySelector = new IEntitySelector() {
        @Override
        public boolean isEntityApplicable(Entity entity) {
            return !isChild() && !isInLove() && isPrey(entity);
        }
    };

    public EntityKhalilAnimal(World world) {
        super(world);
        this.getNavigator().setAvoidsWater(true);

        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIAttackOnCollide(this, 1.5D, true));
        this.tasks.addTask(2, new EntityAIMate(this, 1.0D));
        this.tasks.addTask(3, new EntityAITempt(this, 1.1D, getTemptItem(), false));
        this.tasks.addTask(4, new EntityAIFollowParent(this, 1.1D));
        this.tasks.addTask(5, new EntityAIWander(this, 0.9D));
        this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(7, new EntityAILookIdle(this));

        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true));
        if (isPredator()) {
            this.targetTasks.addTask(2, new EntityAINearestAttackableTarget(this, EntityLiving.class, 300, true, false, this.preySelector));
        }
    }

    // ---- per-species configuration (must not depend on instance fields) ----

    protected abstract double getBaseHealth();

    protected abstract double getBaseSpeed();

    protected abstract double getBaseDamage();

    protected abstract boolean isPredator();

    protected abstract Item getTemptItem();

    protected abstract Item getRawMeat();

    protected abstract Item getCookedMeat();

    // ---- attributes / AI ----

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.attackDamage);
        this.getEntityAttribute(SharedMonsterAttributes.maxHealth).setBaseValue(getBaseHealth());
        this.getEntityAttribute(SharedMonsterAttributes.movementSpeed).setBaseValue(getBaseSpeed());
        this.getEntityAttribute(SharedMonsterAttributes.attackDamage).setBaseValue(getBaseDamage());
    }

    @Override
    public boolean isAIEnabled() {
        return true;
    }

    protected boolean isPrey(Entity entity) {
        return entity instanceof EntitySheep || entity instanceof EntityCow
                || entity instanceof EntityPig || entity instanceof EntityChicken;
    }

    @Override
    public boolean attackEntityAsMob(Entity target) {
        float damage = (float) this.getEntityAttribute(SharedMonsterAttributes.attackDamage).getAttributeValue();
        boolean hit = target.attackEntityFrom(DamageSource.causeMobDamage(this), damage);
        if (hit && target instanceof EntityLivingBase) {
            // small knockback away from the attacker
            double dx = target.posX - this.posX;
            double dz = target.posZ - this.posZ;
            double len = Math.sqrt(dx * dx + dz * dz);
            if (len > 0.0001D) {
                target.addVelocity(dx / len * 0.4D, 0.25D, dz / len * 0.4D);
            }
        }
        return hit;
    }

    // ---- breeding ----

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return stack != null && stack.getItem() == getTemptItem();
    }

    // ---- drops: 5 pieces of meat (cooked if the animal dies burning) ----

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        Item meat = this.isBurning() ? getCookedMeat() : getRawMeat();
        this.entityDropItem(new ItemStack(meat, 5), 0.0F);
    }

    // ---- sounds ----

    @Override
    protected float getSoundVolume() {
        return 1.0F;
    }

    protected void func_145780_a(int x, int y, int z, Block block) {
        this.playSound(getStepSound(), 0.4F, 1.0F);
    }

    protected abstract String getStepSound();
}
