package com.khalil.creatures.entity;

import net.minecraft.entity.EntityAgeable;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

import com.khalil.creatures.ModItems;

public class EntityLion extends EntityKhalilAnimal {

    public EntityLion(World world) {
        super(world);
        this.setSize(1.3F, 1.4F);
        this.setMale(this.rand.nextBoolean());
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        // 0 = lioness, 1 = lion (has a mane)
        this.dataWatcher.addObject(16, Byte.valueOf((byte) 0));
    }

    public boolean isMale() {
        return this.dataWatcher.getWatchableObjectByte(16) == 1;
    }

    public void setMale(boolean male) {
        this.dataWatcher.updateObject(16, Byte.valueOf((byte) (male ? 1 : 0)));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound tag) {
        super.writeEntityToNBT(tag);
        tag.setBoolean("Male", this.isMale());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound tag) {
        super.readEntityFromNBT(tag);
        this.setMale(tag.getBoolean("Male"));
    }

    @Override
    protected double getBaseHealth() {
        return 30.0D;
    }

    @Override
    protected double getBaseSpeed() {
        return 0.25D;
    }

    @Override
    protected double getBaseDamage() {
        return 6.0D;
    }

    @Override
    protected boolean isPredator() {
        return true;
    }

    @Override
    protected Item getTemptItem() {
        return Items.beef;
    }

    @Override
    public boolean isBreedingItem(net.minecraft.item.ItemStack stack) {
        if (stack == null) {
            return false;
        }
        Item item = stack.getItem();
        return item == Items.beef || item == Items.porkchop || item == Items.chicken;
    }

    @Override
    protected Item getRawMeat() {
        return ModItems.rawLionMeat;
    }

    @Override
    protected Item getCookedMeat() {
        return ModItems.cookedLionMeat;
    }

    @Override
    public EntityAgeable createChild(EntityAgeable mate) {
        return new EntityLion(this.worldObj);
    }

    @Override
    protected String getLivingSound() {
        return "khalilcreatures:lion.roar";
    }

    @Override
    protected String getHurtSound() {
        return "khalilcreatures:lion.hurt";
    }

    @Override
    protected String getDeathSound() {
        return "khalilcreatures:lion.death";
    }

    @Override
    protected String getStepSound() {
        return "khalilcreatures:bigcat.step";
    }

    @Override
    public int getTalkInterval() {
        return 240;
    }
}
