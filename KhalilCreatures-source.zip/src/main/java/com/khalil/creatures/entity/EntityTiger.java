package com.khalil.creatures.entity;

import net.minecraft.entity.EntityAgeable;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import com.khalil.creatures.ModItems;

public class EntityTiger extends EntityKhalilAnimal {

    public EntityTiger(World world) {
        super(world);
        this.setSize(1.3F, 1.3F);
    }

    @Override
    protected double getBaseHealth() {
        return 28.0D;
    }

    @Override
    protected double getBaseSpeed() {
        return 0.26D;
    }

    @Override
    protected double getBaseDamage() {
        return 7.0D;
    }

    @Override
    protected boolean isPredator() {
        return true;
    }

    @Override
    protected Item getTemptItem() {
        return Items.beef;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        Item item = stack.getItem();
        return item == Items.beef || item == Items.porkchop || item == Items.chicken;
    }

    @Override
    protected Item getRawMeat() {
        return ModItems.rawTigerMeat;
    }

    @Override
    protected Item getCookedMeat() {
        return ModItems.cookedTigerMeat;
    }

    @Override
    public EntityAgeable createChild(EntityAgeable mate) {
        return new EntityTiger(this.worldObj);
    }

    @Override
    protected String getLivingSound() {
        return "khalilcreatures:tiger.roar";
    }

    @Override
    protected String getHurtSound() {
        return "khalilcreatures:tiger.hurt";
    }

    @Override
    protected String getDeathSound() {
        return "khalilcreatures:tiger.death";
    }

    @Override
    protected String getStepSound() {
        return "khalilcreatures:bigcat.step";
    }

    @Override
    public int getTalkInterval() {
        return 240;
    }
}
