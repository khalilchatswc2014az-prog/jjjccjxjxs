package com.khalil.creatures.proxy;

import com.khalil.creatures.client.model.ModelElephant;
import com.khalil.creatures.client.model.ModelLion;
import com.khalil.creatures.client.model.ModelTiger;
import com.khalil.creatures.client.render.RenderKhalilAnimal;
import com.khalil.creatures.entity.EntityElephant;
import com.khalil.creatures.entity.EntityLion;
import com.khalil.creatures.entity.EntityTiger;

import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {

    @Override
    public void registerRenderers() {
        RenderingRegistry.registerEntityRenderingHandler(EntityLion.class,
                new RenderKhalilAnimal(new ModelLion(), 0.8F, "lion", 1.0F));
        RenderingRegistry.registerEntityRenderingHandler(EntityTiger.class,
                new RenderKhalilAnimal(new ModelTiger(), 0.8F, "tiger", 1.0F));
        RenderingRegistry.registerEntityRenderingHandler(EntityElephant.class,
                new RenderKhalilAnimal(new ModelElephant(), 1.6F, "elephant", 1.5F));
    }
}
