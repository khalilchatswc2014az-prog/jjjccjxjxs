package com.khalil.creatures.proxy;

public class CommonProxy {

    public void registerRenderers() {
        // server side: nothing to render
    }
}
