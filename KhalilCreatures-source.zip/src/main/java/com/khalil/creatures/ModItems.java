package com.khalil.creatures;

import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;

import cpw.mods.fml.common.registry.GameRegistry;

public class ModItems {

    public static ItemFood rawLionMeat;
    public static ItemFood cookedLionMeat;
    public static ItemFood rawTigerMeat;
    public static ItemFood cookedTigerMeat;
    public static ItemFood rawElephantMeat;
    public static ItemFood cookedElephantMeat;

    public static void init() {
        rawLionMeat = register("raw_lion_meat", 3, 0.3F, true);
        cookedLionMeat = register("cooked_lion_meat", 7, 0.8F, false);
        rawTigerMeat = register("raw_tiger_meat", 3, 0.3F, true);
        cookedTigerMeat = register("cooked_tiger_meat", 7, 0.8F, false);
        rawElephantMeat = register("raw_elephant_meat", 4, 0.3F, true);
        cookedElephantMeat = register("cooked_elephant_meat", 9, 0.9F, false);
    }

    public static void registerRecipes() {
        GameRegistry.addSmelting(rawLionMeat, new ItemStack(cookedLionMeat), 0.35F);
        GameRegistry.addSmelting(rawTigerMeat, new ItemStack(cookedTigerMeat), 0.35F);
        GameRegistry.addSmelting(rawElephantMeat, new ItemStack(cookedElephantMeat), 0.35F);
    }

    private static ItemFood register(String name, int heal, float saturation, boolean raw) {
        ItemFood food = new ItemFood(heal, saturation, true);
        food.setUnlocalizedName(KhalilCreatures.MODID + "." + name);
        food.setTextureName(KhalilCreatures.MODID + ":" + name);
        food.setCreativeTab(KhalilCreatures.creativeTab);
        if (raw) {
            food.setPotionEffect(Potion.hunger.id, 15, 0, 0.3F);
        }
        GameRegistry.registerItem(food, name);
        return food;
    }
}
