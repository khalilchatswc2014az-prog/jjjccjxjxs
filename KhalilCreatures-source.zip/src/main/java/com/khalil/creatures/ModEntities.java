package com.khalil.creatures;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.world.biome.BiomeGenBase;

import com.khalil.creatures.entity.EntityElephant;
import com.khalil.creatures.entity.EntityLion;
import com.khalil.creatures.entity.EntityTiger;

import cpw.mods.fml.common.registry.EntityRegistry;

public class ModEntities {

    private static int nextModEntityId = 0;

    public static void init() {
        // name used for NBT / lang key "entity.<name>.name" / spawn egg
        register(EntityLion.class, "KhalilLion", 0xD9A441, 0x6B4A1B);
        register(EntityTiger.class, "KhalilTiger", 0xE8741C, 0x1A1A1A);
        register(EntityElephant.class, "KhalilElephant", 0x8A8A92, 0xCFC8BC);
    }

    private static void register(Class<? extends Entity> entityClass, String name, int eggPrimary, int eggSecondary) {
        int id = EntityRegistry.findGlobalUniqueEntityId();
        // creates the spawn egg too
        EntityRegistry.registerGlobalEntityID(entityClass, name, id, eggPrimary, eggSecondary);
        EntityRegistry.registerModEntity(entityClass, name, nextModEntityId++, KhalilCreatures.instance, 80, 3, true);
    }

    /** Natural spawning, by biome. */
    public static void registerSpawns() {
        // Lion: savanna and open plains
        EntityRegistry.addSpawn(EntityLion.class, 10, 1, 4, EnumCreatureType.creature,
                BiomeGenBase.savanna, BiomeGenBase.savannaPlateau);
        EntityRegistry.addSpawn(EntityLion.class, 2, 1, 2, EnumCreatureType.creature,
                BiomeGenBase.plains);

        // Tiger: jungle and cold forests (Siberian tiger)
        EntityRegistry.addSpawn(EntityTiger.class, 8, 1, 2, EnumCreatureType.creature,
                BiomeGenBase.jungle, BiomeGenBase.jungleHills, BiomeGenBase.jungleEdge);
        EntityRegistry.addSpawn(EntityTiger.class, 3, 1, 2, EnumCreatureType.creature,
                BiomeGenBase.taiga, BiomeGenBase.taigaHills, BiomeGenBase.coldTaiga);

        // Elephant: savanna, jungle edge and plains (herds)
        EntityRegistry.addSpawn(EntityElephant.class, 8, 2, 5, EnumCreatureType.creature,
                BiomeGenBase.savanna, BiomeGenBase.savannaPlateau);
        EntityRegistry.addSpawn(EntityElephant.class, 4, 1, 3, EnumCreatureType.creature,
                BiomeGenBase.jungle, BiomeGenBase.jungleEdge);
        EntityRegistry.addSpawn(EntityElephant.class, 2, 1, 3, EnumCreatureType.creature,
                BiomeGenBase.plains);
    }
}
