package com.khalil.creatures.client.render;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

import com.khalil.creatures.KhalilCreatures;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

/** One renderer for all three animals: only model, texture and size differ. */
@SideOnly(Side.CLIENT)
public class RenderKhalilAnimal extends RenderLiving {

    private final ResourceLocation texture;
    private final float modelScale;

    public RenderKhalilAnimal(ModelBase model, float shadowSize, String textureName, float modelScale) {
        super(model, shadowSize);
        this.texture = new ResourceLocation(KhalilCreatures.MODID, "textures/entity/" + textureName + ".png");
        this.modelScale = modelScale;
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return this.texture;
    }

    @Override
    protected void preRenderCallback(EntityLivingBase entity, float partialTicks) {
        float s = entity.isChild() ? this.modelScale * 0.55F : this.modelScale;
        GL11.glScalef(s, s, s);
    }
}
