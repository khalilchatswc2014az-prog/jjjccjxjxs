package com.khalil.creatures;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

import com.khalil.creatures.proxy.CommonProxy;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@Mod(modid = KhalilCreatures.MODID, name = KhalilCreatures.NAME, version = KhalilCreatures.VERSION, acceptedMinecraftVersions = "[1.7.10]")
public class KhalilCreatures {

    public static final String MODID = "khalilcreatures";
    public static final String NAME = "Khalil Creatures";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static KhalilCreatures instance;

    @SidedProxy(clientSide = "com.khalil.creatures.proxy.ClientProxy", serverSide = "com.khalil.creatures.proxy.CommonProxy")
    public static CommonProxy proxy;

    public static final CreativeTabs creativeTab = new CreativeTabs("khalilCreatures") {
        @Override
        @SideOnly(Side.CLIENT)
        public Item getTabIconItem() {
            return ModItems.rawLionMeat;
        }
    };

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModItems.init();
        ModEntities.init();
        proxy.registerRenderers();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        ModItems.registerRecipes();
        ModEntities.registerSpawns();
    }
}
