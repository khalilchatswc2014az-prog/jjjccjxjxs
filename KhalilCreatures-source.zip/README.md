# Khalil Creatures (Minecraft Forge 1.7.10)
أسد 🦁 + نمر 🐅 + فيل 🐘 / Lion, Tiger, Elephant.

## البناء / Build
1. حمّل Forge MDK الرسمي: forge-1.7.10-10.13.4.1614-1.7.10-mdk (مع JDK 8).
2. انسخ مجلد `src` وملف `build.gradle` من هذا المشروع فوق ملفات الـ MDK.
3. شغّل: `gradlew setupDecompWorkspace` ثم `gradlew build`
4. الناتج: `build/libs/KhalilCreatures-1.7.10.jar` -> ضعه في مجلد mods.

## إعادة توليد الموارد / Regenerate assets
`python3 tools/generate_assets.py` (numpy, scipy, Pillow, ffmpeg)
