#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Khalil Creatures - asset generator.

Generates from ONE shared box specification:
  * the Java ModelBase classes (ModelLion / ModelTiger / ModelElephant)
  * the matching entity textures (UV layout is computed from the same boxes,
    so model and texture can never get out of sync)
  * item textures (raw / cooked meat)
  * OGG Vorbis sounds (needs numpy, scipy and ffmpeg with libvorbis)

Run:  python3 tools/generate_assets.py
"""
import os
import math
import random
import string
import subprocess
import tempfile

import numpy as np
from PIL import Image
from scipy import signal
from scipy.io import wavfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
ASSETS = os.path.join(ROOT, 'src/main/resources/assets/khalilcreatures')
MODEL_DIR = os.path.join(ROOT, 'src/main/java/com/khalil/creatures/client/model')


# ----------------------------------------------------------------------------
# Model spec
# ----------------------------------------------------------------------------
class Part(object):
    def __init__(self, name, role, box, pivot, parent=None, rot=(0.0, 0.0, 0.0)):
        self.name = name
        self.role = role
        self.box = box          # (offX, offY, offZ, w, h, d)
        self.pivot = pivot      # rotation point
        self.parent = parent
        self.rot = rot
        self.u = 0
        self.v = 0

    @property
    def tw(self):
        return 2 * (int(self.box[5]) + int(self.box[3]))

    @property
    def th(self):
        return int(self.box[5]) + int(self.box[4])


def lion_parts():
    P = []
    P.append(Part('body', 'body', (-4, -5, -10, 8, 9, 20), (0, 10, 0)))
    P.append(Part('head', 'head', (-4, -4, -6, 8, 8, 6), (0, 8, -10)))
    P.append(Part('snout', 'snout', (-2, 0, -9, 4, 3, 3), (0, 0, 0), 'head'))
    P.append(Part('earL', 'ear', (1, -6, -3, 3, 2, 2), (0, 0, 0), 'head'))
    P.append(Part('earR', 'ear', (-4, -6, -3, 3, 2, 2), (0, 0, 0), 'head'))
    P.append(Part('mane', 'mane', (-6, -6, -2, 12, 12, 5), (0, 0, 0), 'head'))
    P.append(Part('legFL', 'leg', (-1.5, 0, -1.5, 3, 11, 3), (2.5, 13, -7)))
    P.append(Part('legFR', 'leg', (-1.5, 0, -1.5, 3, 11, 3), (-2.5, 13, -7)))
    P.append(Part('legBL', 'leg', (-1.5, 0, -1.5, 3, 11, 3), (2.5, 13, 7)))
    P.append(Part('legBR', 'leg', (-1.5, 0, -1.5, 3, 11, 3), (-2.5, 13, 7)))
    P.append(Part('tail', 'tail', (-1, 0, -1, 2, 9, 2), (0, 6, 10)))
    P.append(Part('tuft', 'tuft', (-1.5, 8, -1.5, 3, 3, 3), (0, 0, 0), 'tail'))
    return P


def tiger_parts():
    P = []
    P.append(Part('body', 'body', (-4, -4, -11, 8, 8, 22), (0, 11, 0)))
    P.append(Part('head', 'head', (-3.5, -3.5, -6, 7, 7, 6), (0, 9, -11)))
    P.append(Part('snout', 'snout', (-2, 0, -8, 4, 3, 2), (0, 0, 0), 'head'))
    P.append(Part('earL', 'ear', (1.5, -5, -3, 2, 2, 2), (0, 0, 0), 'head'))
    P.append(Part('earR', 'ear', (-3.5, -5, -3, 2, 2, 2), (0, 0, 0), 'head'))
    P.append(Part('legFL', 'leg', (-1.5, 0, -1.5, 3, 10, 3), (2.5, 14, -8)))
    P.append(Part('legFR', 'leg', (-1.5, 0, -1.5, 3, 10, 3), (-2.5, 14, -8)))
    P.append(Part('legBL', 'leg', (-1.5, 0, -1.5, 3, 10, 3), (2.5, 14, 8)))
    P.append(Part('legBR', 'leg', (-1.5, 0, -1.5, 3, 10, 3), (-2.5, 14, 8)))
    P.append(Part('tail', 'tail', (-1, 0, -1, 2, 10, 2), (0, 8, 11)))
    return P


def elephant_parts():
    P = []
    P.append(Part('body', 'body', (-8, -9, -13, 16, 18, 26), (0, 2, 0)))
    P.append(Part('head', 'head', (-6, -7, -9, 12, 14, 9), (0, 1, -13)))
    P.append(Part('trunk1', 'trunk1', (-2.5, 0, -2.5, 5, 9, 5), (0, -2, -9), 'head'))
    P.append(Part('trunk2', 'trunk2', (-2, 0, -2, 4, 8, 4), (0, 9, 0), 'trunk1'))
    P.append(Part('tuskL', 'tusk', (-1, 0, -7, 2, 2, 8), (4, 4, -8), 'head', (0.35, 0, 0)))
    P.append(Part('tuskR', 'tusk', (-1, 0, -7, 2, 2, 8), (-4, 4, -8), 'head', (0.35, 0, 0)))
    P.append(Part('earL', 'ear', (0, 0, 0, 1, 10, 9), (6, -5, -3), 'head'))
    P.append(Part('earR', 'ear', (-1, 0, 0, 1, 10, 9), (-6, -5, -3), 'head'))
    P.append(Part('legFL', 'leg', (-3, 0, -3, 6, 14, 6), (5, 10, -8)))
    P.append(Part('legFR', 'leg', (-3, 0, -3, 6, 14, 6), (-5, 10, -8)))
    P.append(Part('legBL', 'leg', (-3, 0, -3, 6, 14, 6), (5, 10, 8)))
    P.append(Part('legBR', 'leg', (-3, 0, -3, 6, 14, 6), (-5, 10, 8)))
    P.append(Part('tail', 'tail', (-1, 0, -1, 2, 13, 2), (0, 0, 13)))
    P.append(Part('tuft', 'tuft', (-1.5, 13, -1.5, 3, 3, 3), (0, 0, 0), 'tail'))
    return P


# ----------------------------------------------------------------------------
# UV packing + painting
# ----------------------------------------------------------------------------
def pack(parts):
    for size in (64, 128, 256):
        x = y = rowh = 0
        ok = True
        for p in sorted(parts, key=lambda q: (-q.th, -q.tw)):
            if x + p.tw > size:
                x = 0
                y += rowh
                rowh = 0
            if y + p.th > size:
                ok = False
                break
            p.u, p.v = x, y
            x += p.tw
            rowh = max(rowh, p.th)
        if ok:
            return size
    raise RuntimeError('texture does not fit')


def jit(c, n, amt):
    f = 1.0 + (n - 0.5) * amt * 2.0
    return tuple(max(0, min(255, int(v * f))) for v in c)


def paint_texture(parts, size, painter, seed):
    img = np.zeros((size, size, 4), dtype=np.uint8)
    for p in parts:
        r = random.Random(seed + p.name)
        w, h, d = int(p.box[3]), int(p.box[4]), int(p.box[5])
        u, v = p.u, p.v
        rects = {
            'left': (u, v + d, d, h),
            'front': (u + d, v + d, w, h),
            'right': (u + d + w, v + d, d, h),
            'back': (u + d + w + d, v + d, w, h),
            'top': (u + d, v, w, d),
            'bottom': (u + d + w, v, w, d),
        }
        for face, (x0, y0, fw, fh) in rects.items():
            for fy in range(fh):
                for fx in range(fw):
                    c = painter(p, face, fx, fy, fw, fh, r)
                    img[y0 + fy, x0 + fx] = (c[0], c[1], c[2], 255)
    return img


def paint_lion(p, face, fx, fy, fw, fh, r):
    n = r.random()
    role = p.role
    TAN = (201, 160, 92)
    LIGHT = (231, 207, 158)
    DARK = (108, 64, 26)
    if role == 'mane':
        c = DARK
        k = (fx * 3 + (fy // 2) * 2) % 7
        if k == 0:
            c = (76, 42, 16)
        elif k == 3:
            c = (146, 94, 42)
        return jit(c, n, .2)
    if role == 'tuft':
        return jit((88, 50, 20), n, .2)
    if role == 'ear':
        if face == 'front':
            return jit((180, 120, 100), n, .1)
        return jit((165, 124, 70), n, .12)
    if role == 'snout':
        if face == 'front':
            if fy == 0 and fw // 2 - 1 <= fx <= fw // 2:
                return (150, 84, 84)
            if fy == fh - 1:
                return (110, 62, 40)
        return jit(LIGHT, n, .1)
    if role == 'head':
        if face == 'front':
            if fy == 2 and fx in (1, 2, fw - 3, fw - 2):
                if fx in (2, fw - 3):
                    return (30, 22, 10)
                return (226, 168, 34)
            if fy == 1 and fx in (1, 2, fw - 3, fw - 2):
                return (140, 100, 52)
            if fy >= fh - 2:
                return jit(LIGHT, n, .08)
        if face == 'top':
            return jit((186, 145, 82), n, .1)
        if face == 'bottom':
            return jit(LIGHT, n, .08)
        return jit(TAN, n, .1)
    if role == 'body':
        if face == 'bottom':
            return jit(LIGHT, n, .08)
        if face == 'top':
            return jit((186, 146, 82), n, .12)
        if fy >= fh - 2:
            return jit((222, 192, 138), n, .1)
        return jit(TAN, n, .12)
    if role == 'leg':
        if face == 'bottom':
            return jit((140, 100, 60), n, .1)
        if fy >= fh - 2:
            return jit((216, 184, 128), n, .1)
        return jit(TAN, n, .12)
    return jit(TAN, n, .12)


def paint_tiger(p, face, fx, fy, fw, fh, r):
    n = r.random()
    OR = (220, 118, 34)
    WH = (240, 232, 216)
    BK = (30, 24, 20)
    role = p.role

    def stripe(a, b):
        col = (a + (b // 3) % 2) % 5
        return col == 0 or (col == 1 and b % 4 < 2)

    if role == 'tail':
        return jit(BK if fy % 3 == 0 else OR, n, .1)
    if role == 'ear':
        if face == 'back':
            return jit(WH, n, .05)
        return jit(BK, n, .05)
    if role == 'snout':
        if face == 'front':
            if fy == 0 and fx in (1, 2):
                return (206, 120, 120)
            if fy == fh - 1:
                return BK
        return jit(WH, n, .06)
    if role == 'head':
        if face == 'front':
            if fy == 2 and fx in (1, 2, fw - 3, fw - 2):
                if fx in (2, fw - 3):
                    return (20, 16, 12)
                return (206, 204, 40)
            if fy == 1 and fx in (1, 2, fw - 3, fw - 2):
                return BK
            if fy == 0 and fx % 2 == 1:
                return BK
            if fy >= fh - 2:
                return jit(WH, n, .06)
            return jit(OR, n, .1)
        if face == 'top':
            return jit(BK if (fx % 2 == 1 and fy % 3 != 2) else OR, n, .08)
        if face == 'bottom':
            return jit(WH, n, .06)
        if face in ('left', 'right'):
            if fy >= fh - 2:
                return jit(WH, n, .06)
            return jit(BK if ((fx + fy // 2) % 3 == 0 and fy < 5) else OR, n, .08)
        return jit(OR, n, .1)
    if role == 'body':
        if face == 'bottom':
            return jit(WH, n, .06)
        if face == 'top':
            return jit(BK if stripe(fy, fx) else OR, n, .08)
        if fy >= fh - 2:
            return jit(WH, n, .06)
        return jit(BK if stripe(fx, fy) else OR, n, .08)
    if role == 'leg':
        if face == 'bottom':
            return jit((190, 110, 50), n, .1)
        if fy >= fh - 2:
            return jit(WH, n, .06)
        if fy % 4 == 1 and fx % 3 != 1:
            return jit(BK, n, .08)
        return jit(OR, n, .1)
    return jit(OR, n, .1)


def paint_elephant(p, face, fx, fy, fw, fh, r):
    n = r.random()
    G = (124, 124, 130)
    DG = (98, 98, 104)
    LG = (150, 138, 140)
    role = p.role
    if role == 'tusk':
        return jit((238, 232, 210), n, .08)
    if role == 'tuft':
        return jit((66, 66, 72), n, .15)
    if role == 'ear':
        if face in ('left', 'right'):
            edge = min(fx, fy, fw - 1 - fx, fh - 1 - fy)
            if edge == 0:
                return jit(G, n, .12)
            vein = (fx * 2 + fy) % 6 == 0
            return jit((150, 112, 116) if vein else (176, 142, 144), n, .1)
        return jit(G, n, .12)
    if role in ('trunk1', 'trunk2'):
        if role == 'trunk2' and face == 'bottom':
            return jit((58, 48, 52), n, .1)
        if fy % 2 == 0:
            return jit(DG, n, .12)
        return jit(G, n, .14)
    if role == 'head' and face == 'front':
        if fy == 4 and fx in (1, fw - 2):
            return (20, 18, 18)
        if fy == 3 and fx in (1, 2, fw - 3, fw - 2):
            return jit(DG, n, .08)
    if face == 'bottom' and role in ('body', 'leg', 'head'):
        return jit(LG, n, .1)
    if role == 'leg' and face == 'front' and fy >= fh - 2 and fx % 2 == 0:
        return jit((208, 200, 178), n, .08)
    wr = (fy * 3 + fx // 4) % 8 == 0
    return jit(DG if wr else G, n, .14)


def write_png(path, arr):
    Image.fromarray(arr, 'RGBA').save(path)


def meat_sprite(base, shade, fat, cooked, seed):
    img = np.zeros((16, 16, 4), np.uint8)
    rs = random.Random(seed)
    ca, sa = math.cos(0.7), math.sin(0.7)
    for y in range(16):
        for x in range(16):
            dx, dy = x - 6.5, y - 6.5
            rx = dx * ca + dy * sa
            ry = -dx * sa + dy * ca
            e = (rx / 6.3) ** 2 + (ry / 4.4) ** 2
            if e <= 1.0:
                if e > 0.68:
                    c = shade
                else:
                    c = base
                    if cooked:
                        if (x + y) % 4 == 0:
                            c = tuple(int(v * 0.72) for v in base)
                    else:
                        if rs.random() < 0.14:
                            c = fat
                    if e < 0.2:
                        c = tuple(min(255, int(v * 1.12)) for v in c)
                img[y, x] = (c[0], c[1], c[2], 255)
    bone = (236, 230, 214, 255)
    for (x, y) in [(11, 11), (12, 12), (13, 13), (13, 14), (14, 13), (14, 14)]:
        img[y, x] = bone
    return img


# ----------------------------------------------------------------------------
# Java model emission
# ----------------------------------------------------------------------------
def jf(x):
    return repr(float(x)) + 'F'


CAT_ANIM = string.Template(r'''
    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale, Entity entity) {
        float rad = 0.017453292F;
        float pi = (float) Math.PI;
        float amp = MathHelper.clamp_float(limbSwingAmount, 0.0F, 1.0F);
        // 0 = walking, 1 = running (blended)
        float run = MathHelper.clamp_float((amp - 0.6F) / 0.3F, 0.0F, 1.0F);
        float s = limbSwing * 0.6662F;

        // walk: diagonal gait
        float wA = MathHelper.cos(s) * 1.0F * amp;
        float wB = MathHelper.cos(s + pi) * 1.0F * amp;
        // run: gallop, front legs together and back legs together
        float gF = MathHelper.cos(s) * 1.4F * amp;
        float gB = MathHelper.cos(s + 1.1F) * 1.4F * amp;

        this.legFL.rotateAngleX = wA + (gF - wA) * run;
        this.legBR.rotateAngleX = wA + (gB - wA) * run;
        this.legFR.rotateAngleX = wB + (gF - wB) * run;
        this.legBL.rotateAngleX = wB + (gB - wB) * run;

        // body bob while moving, slow breathing while standing
        float dy = -Math.abs(MathHelper.sin(s)) * 0.9F * amp * (0.3F + run)
                + MathHelper.sin(ageInTicks * 0.09F) * 0.25F * (1.0F - amp);
        this.body.rotationPointY = $BODY_Y + dy;
        this.head.rotationPointY = $HEAD_Y + dy;
        this.tail.rotationPointY = $TAIL_Y + dy;

        this.head.rotateAngleX = headPitch * rad + 0.12F * run
                + MathHelper.sin(ageInTicks * 0.05F) * 0.03F * (1.0F - amp);
        this.head.rotateAngleY = netHeadYaw * rad;
        if (this.onGround > 0.0F) {
            // biting / attack lunge
            this.head.rotateAngleX += MathHelper.sin(this.onGround * pi) * 0.7F;
        }

        this.tail.rotateAngleX = 0.5F + 0.6F * run + MathHelper.cos(ageInTicks * 0.1F) * 0.05F;
        this.tail.rotateAngleY = MathHelper.sin(ageInTicks * 0.07F) * 0.2F * (1.0F - amp)
                + MathHelper.cos(s) * 0.25F * amp;
$EXTRA    }
''')

LION_EXTRA = r'''
        boolean male = entity instanceof EntityLion && ((EntityLion) entity).isMale();
        this.mane.showModel = male && !this.isChild;
'''

ELEPHANT_ANIM = string.Template(r'''
    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale, Entity entity) {
        float rad = 0.017453292F;
        float pi = (float) Math.PI;
        float amp = MathHelper.clamp_float(limbSwingAmount, 0.0F, 1.0F);
        float s = limbSwing * 0.55F;

        float a = MathHelper.cos(s) * 0.95F * amp;
        float b = MathHelper.cos(s + pi) * 0.95F * amp;
        this.legFL.rotateAngleX = a;
        this.legBR.rotateAngleX = a;
        this.legFR.rotateAngleX = b;
        this.legBL.rotateAngleX = b;

        float dy = -Math.abs(MathHelper.sin(s)) * 0.5F * amp
                + MathHelper.sin(ageInTicks * 0.06F) * 0.3F * (1.0F - amp);
        this.body.rotationPointY = $BODY_Y + dy;
        this.head.rotationPointY = $HEAD_Y + dy;
        this.tail.rotationPointY = $TAIL_Y + dy;

        this.head.rotateAngleX = headPitch * rad + MathHelper.sin(ageInTicks * 0.05F) * 0.03F;
        this.head.rotateAngleY = netHeadYaw * rad;

        float t = ageInTicks * 0.07F;
        this.trunk1.rotateAngleX = 0.1F + MathHelper.sin(t) * 0.12F + MathHelper.cos(s) * 0.12F * amp;
        this.trunk2.rotateAngleX = -0.35F + MathHelper.sin(t + 1.0F) * 0.15F;

        float flap = MathHelper.sin(ageInTicks * 0.11F) * 0.1F + MathHelper.sin(s * 2.0F) * 0.12F * amp;
        this.earL.rotateAngleY = 0.35F + flap;
        this.earR.rotateAngleY = -(0.35F + flap);

        this.tail.rotateAngleX = 0.15F;
        this.tail.rotateAngleZ = MathHelper.sin(ageInTicks * 0.08F) * 0.25F + MathHelper.cos(s) * 0.3F * amp;

        if (this.onGround > 0.0F) {
            // trunk swing / head toss when attacking
            float sw = MathHelper.sin(this.onGround * pi);
            this.trunk1.rotateAngleX -= sw * 1.3F;
            this.head.rotateAngleX -= sw * 0.25F;
        }
    }
''')


def gen_model(cls, parts, size, anim, entity_import=None):
    P = dict((p.name, p) for p in parts)
    out = []
    out.append('package com.khalil.creatures.client.model;\n')
    if entity_import:
        out.append('import %s;' % entity_import)
    out.append('import net.minecraft.client.model.ModelBase;')
    out.append('import net.minecraft.client.model.ModelRenderer;')
    out.append('import net.minecraft.entity.Entity;')
    out.append('import net.minecraft.util.MathHelper;')
    out.append('import cpw.mods.fml.relauncher.Side;')
    out.append('import cpw.mods.fml.relauncher.SideOnly;\n')
    out.append('/** AUTO-GENERATED by tools/generate_assets.py (model + texture share one box spec). */')
    out.append('@SideOnly(Side.CLIENT)')
    out.append('public class %s extends ModelBase {' % cls)
    for p in parts:
        out.append('    public ModelRenderer %s;' % p.name)
    out.append('')
    out.append('    public %s() {' % cls)
    out.append('        this.textureWidth = %d;' % size)
    out.append('        this.textureHeight = %d;' % size)
    for p in parts:
        ox, oy, oz, w, h, d = p.box
        out.append('        this.%s = new ModelRenderer(this, %d, %d);' % (p.name, p.u, p.v))
        out.append('        this.%s.addBox(%s, %s, %s, %d, %d, %d);' % (p.name, jf(ox), jf(oy), jf(oz), w, h, d))
        out.append('        this.%s.setRotationPoint(%s, %s, %s);' % (p.name, jf(p.pivot[0]), jf(p.pivot[1]), jf(p.pivot[2])))
        for axis, val in zip('XYZ', p.rot):
            if val:
                out.append('        this.%s.rotateAngle%s = %s;' % (p.name, axis, jf(val)))
    for p in parts:
        if p.parent:
            out.append('        this.%s.addChild(this.%s);' % (p.parent, p.name))
    out.append('    }\n')
    out.append('    @Override')
    out.append('    public void render(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {')
    out.append('        this.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, entity);')
    for p in parts:
        if not p.parent:
            out.append('        this.%s.render(scale);' % p.name)
    out.append('    }')
    subs = dict(
        BODY_Y=jf(P['body'].pivot[1]),
        HEAD_Y=jf(P['head'].pivot[1]),
        TAIL_Y=jf(P['tail'].pivot[1]),
        EXTRA=anim[1],
    )
    out.append(anim[0].substitute(**subs).rstrip('\n'))
    out.append('}')
    return '\n'.join(out) + '\n'


# ----------------------------------------------------------------------------
# Sounds
# ----------------------------------------------------------------------------
SR = 22050


def _sos(kind, c):
    return signal.butter(2, c, btype=kind, fs=SR, output='sos')


def bp(x, lo, hi):
    return signal.sosfilt(_sos('band', [max(40, lo), min(SR * 0.45, hi)]), x)


def lp(x, c):
    return signal.sosfilt(_sos('low', min(c, SR * 0.45)), x)


def hp(x, c):
    return signal.sosfilt(_sos('high', c), x)


def voice(dur, f0, nh=20, tilt=1.0, am=(0, 0), noise=0.2, lpc=3000, hpc=60,
          atk=0.04, rel=0.25, vib=(5.0, 0.012), seed=1, formants=()):
    rs = np.random.RandomState(seed)
    n = int(dur * SR)
    t = np.arange(n) / float(SR)
    x = t / dur
    f = f0(x) * (1.0 + vib[1] * np.sin(2 * np.pi * vib[0] * t))
    ph = 2 * np.pi * np.cumsum(f) / SR
    sig = np.zeros(n)
    for k in range(1, nh + 1):
        if f.max() * k > SR * 0.45:
            break
        sig += np.sin(k * ph + 0.3 * k) / (k ** tilt)
    sig /= (np.max(np.abs(sig)) + 1e-9)
    nz = bp(rs.randn(n), 120, 3500)
    nz /= (np.max(np.abs(nz)) + 1e-9)
    sig = sig + noise * nz
    if am[0] > 0:
        sig *= (1 - am[1]) + am[1] * (0.5 + 0.5 * np.sin(2 * np.pi * am[0] * t))
    sig = hp(lp(sig, lpc), hpc)
    if formants:
        mix = sig * 0.5
        for c, bw, g in formants:
            mix += g * bp(sig, c - bw / 2.0, c + bw / 2.0)
        sig = mix
    env = np.clip(t / atk, 0, 1) * np.clip((dur - t) / rel, 0, 1) ** 1.2
    sig = sig * env
    sig /= (np.max(np.abs(sig)) + 1e-9)
    return (sig * 0.85).astype(np.float32)


def step_sound(freq, dur, seed):
    rs = np.random.RandomState(seed)
    n = int(dur * SR)
    t = np.arange(n) / float(SR)
    thump = np.sin(2 * np.pi * freq * t) * np.exp(-t * 11)
    nz = lp(rs.randn(n), 320) * np.exp(-t * 17)
    sig = thump + 0.6 * nz / (np.max(np.abs(nz)) + 1e-9)
    sig /= (np.max(np.abs(sig)) + 1e-9)
    return (sig * 0.9).astype(np.float32)


def sound_table():
    S = {}
    S['lion_roar'] = voice(2.4, lambda x: 62 + 70 * np.exp(-2.5 * x), nh=30, tilt=0.8, am=(24, .55),
                           noise=.45, lpc=2600, atk=.15, rel=.8, seed=11,
                           formants=[(500, 300, 1.0), (1100, 500, .7)])
    S['lion_hurt'] = voice(.55, lambda x: 150 + 90 * (1 - x), nh=24, am=(30, .4), noise=.3,
                           lpc=3000, atk=.02, rel=.2, seed=12, formants=[(600, 300, 1.0)])
    S['lion_death'] = voice(1.6, lambda x: 140 * (1 - .55 * x), nh=26, am=(20, .5), noise=.35,
                            lpc=2600, atk=.05, rel=.9, seed=13, formants=[(500, 300, 1.0)])
    S['tiger_roar'] = voice(1.9, lambda x: 95 + 110 * np.exp(-4 * x), nh=30, tilt=.7, am=(38, .6),
                            noise=.6, lpc=3200, atk=.08, rel=.6, seed=21,
                            formants=[(650, 350, 1.0), (1500, 600, .6)])
    S['tiger_hurt'] = voice(.5, lambda x: 240 - 60 * x, nh=24, am=(34, .4), noise=.5,
                            lpc=3400, atk=.02, rel=.18, seed=22, formants=[(800, 400, 1.0)])
    S['tiger_death'] = voice(1.5, lambda x: 170 * (1 - .6 * x), nh=26, am=(26, .5), noise=.5,
                             lpc=3000, atk=.04, rel=.8, seed=23, formants=[(650, 350, 1.0)])
    S['elephant_call'] = voice(1.7, lambda x: 280 + 240 * np.sin(np.pi * x ** 0.6), nh=25, tilt=.9,
                               noise=.12, lpc=4500, vib=(7, .025), atk=.08, rel=.35, seed=31,
                               formants=[(900, 500, 1.0), (2200, 900, .7)])
    S['elephant_hurt'] = voice(.8, lambda x: 380 + 80 * np.sin(np.pi * x), nh=22, tilt=.9, noise=.15,
                               lpc=4200, vib=(8, .03), atk=.03, rel=.3, seed=32,
                               formants=[(1000, 500, 1.0)])
    S['elephant_death'] = voice(2.4, lambda x: 420 * np.exp(-1.6 * x) + 90, nh=26, tilt=.9, noise=.2,
                                lpc=3800, vib=(6, .03), atk=.05, rel=1.0, seed=33,
                                formants=[(800, 450, 1.0)])
    S['elephant_step'] = step_sound(52, .45, 41)
    S['big_cat_step'] = step_sound(110, .18, 42)
    return S


def write_ogg(name, data):
    out = os.path.join(ASSETS, 'sounds', name + '.ogg')
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
        wav = tmp.name
    wavfile.write(wav, SR, (data * 32767).astype(np.int16))
    subprocess.check_call(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-ac', '1',
                           '-c:a', 'libvorbis', '-q:a', '4', out])
    os.remove(wav)


# ----------------------------------------------------------------------------
def main():
    for d in ('sounds', 'textures/entity', 'textures/items'):
        os.makedirs(os.path.join(ASSETS, d), exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)

    specs = [
        ('lion', 'ModelLion', lion_parts(), paint_lion, (CAT_ANIM, LION_EXTRA),
         'com.khalil.creatures.entity.EntityLion'),
        ('tiger', 'ModelTiger', tiger_parts(), paint_tiger, (CAT_ANIM, ''), None),
        ('elephant', 'ModelElephant', elephant_parts(), paint_elephant, (ELEPHANT_ANIM, ''), None),
    ]
    for key, cls, parts, painter, anim, imp in specs:
        size = pack(parts)
        write_png(os.path.join(ASSETS, 'textures/entity/%s.png' % key),
                  paint_texture(parts, size, painter, key))
        with open(os.path.join(MODEL_DIR, cls + '.java'), 'w') as fh:
            fh.write(gen_model(cls, parts, size, anim, imp))
        print('model + texture:', key, '(%dx%d)' % (size, size))

    items = [
        ('raw_lion_meat', (196, 72, 62), (130, 38, 36), (240, 190, 170), False),
        ('cooked_lion_meat', (150, 98, 56), (92, 56, 30), (0, 0, 0), True),
        ('raw_tiger_meat', (212, 90, 52), (140, 52, 30), (244, 200, 160), False),
        ('cooked_tiger_meat', (160, 100, 48), (96, 58, 26), (0, 0, 0), True),
        ('raw_elephant_meat', (178, 84, 98), (118, 48, 62), (230, 190, 200), False),
        ('cooked_elephant_meat', (140, 94, 76), (84, 56, 44), (0, 0, 0), True),
    ]
    for name, base, shade, fat, cooked in items:
        write_png(os.path.join(ASSETS, 'textures/items/%s.png' % name),
                  meat_sprite(base, shade, fat, cooked, name))
    print('item textures:', len(items))

    for name, data in sound_table().items():
        write_ogg(name, data)
    print('sounds done')


if __name__ == '__main__':
    main()
